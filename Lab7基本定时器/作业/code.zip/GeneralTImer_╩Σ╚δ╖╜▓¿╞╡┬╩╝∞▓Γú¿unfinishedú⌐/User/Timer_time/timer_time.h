#ifndef __TIMER_TIME_H
#define __TIMER_TIME_H

#include "stm32f10x.h"

#define            GENERAL_TIM_Period           ?
#define            GENERAL_TIM_Prescaler         ?

void GENERAL_TIM_Init(void);
#endif
